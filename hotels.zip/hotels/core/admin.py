# accounts/admin.py
from django.contrib import admin
from .models import User, Hotel, Table, Category, FoodItem, Order


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'role', 'is_active', 'is_staff')
    list_filter = ('role', 'is_active', 'is_staff')
    search_fields = ('username', 'email')


@admin.register(Hotel)
class HotelAdmin(admin.ModelAdmin):
    list_display = ('name', 'address', 'contact_number')
    search_fields = ('name', 'address')


@admin.register(Table)
class TableAdmin(admin.ModelAdmin):
    list_display = ('table_number', 'hotel', 'seats', 'status')
    list_filter = ('hotel', 'status')
    search_fields = ('table_number',)
    list_editable = ('status',)


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'hotel')
    list_filter = ('hotel',)
    search_fields = ('name',)


@admin.register(FoodItem)
class FoodItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'hotel', 'category', 'price')
    list_filter = ('hotel', 'category')
    search_fields = ('name', 'description')


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'table', 'total_price', 'is_paid', 'created_at')
    list_filter = ('is_paid', 'table__hotel')
    search_fields = ('id', 'table__table_number')

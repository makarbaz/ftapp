from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.login_page, name='login_page'),
    path("logout/", views.logout_view, name="logout"),
    path('menu_list/', views.menu_list, name='menu-list'),
    path('home/', views.home, name='home'),
    path('menu/', views.FoodItemList.as_view(), name='fooditem-list'),
    path('tables/create/', views.create_table, name='create_table'),
    path('tables/', views.table_list, name='table_list'),
    path("menu/<int:table_id>/", views.menu_view, name="menu_view"),
    path('create-hotel-user/', views.create_hotel, name='create_hotel_user'),
 
]
# if settings.DEBUG:
#     urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

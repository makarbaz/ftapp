from django.shortcuts import render,redirect

from rest_framework import generics
from .models import FoodItem
from .serializers import FoodItemSerializer
from django.contrib.auth import authenticate, login
# Create your views here.
from django.contrib import messages
from django.contrib.auth import logout
from .models import Table
from django.contrib.auth.decorators import login_required


def home(request):
    return render(request, 'hotels/home.html')



class FoodItemList(generics.ListAPIView):
    queryset = FoodItem.objects.all()
    serializer_class = FoodItemSerializer




def login_page(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect("home")
        else:
            messages.error(request, "Invalid username or password.")
            return redirect("login_page")

    return render(request, "users/login.html")


def logout_view(request):
    logout(request)  # Clears the session
    return redirect("login_page") 



from django.shortcuts import render, redirect
from .models import Hotel, User
from django.contrib import messages
from django.contrib.auth.hashers import make_password


@login_required
def create_hotel(request):
    if request.method == "POST":
        hotel_name = request.POST.get("hotel_name")
        address = request.POST.get("address")
        contact_number = request.POST.get("contact_number")
        role = request.POST.get("role")
        username = request.POST.get("username")
        password = request.POST.get("password")
        confirm_password = request.POST.get("confirm_password")
      

        # Check if passwords match
        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return redirect("create_hotel")  # reload the form

        # Create Hotel
        hotel = Hotel.objects.create(
            name=hotel_name,
            address=address,
            contact_number=contact_number
        )

        # Create Owner User
        user = User.objects.create(
            username=username,
            password=make_password(password),
            role=role,
            # add hotel field if User model has hotel FK
        )
        if hotel:
            user.hotel = hotel
            user.save()

        messages.success(request, f"Hotel '{hotel_name}' and owner '{username}' created successfully!")
        return redirect("login_page")

    return render(request, "users/create_hotel.html")






@login_required
def menu_list(request):
    """
    Displays a list of all menu items.
    """
    menu_items = FoodItem.objects.all().order_by('name') # Order by name for consistency
    context = {
        'menu_items': menu_items,
        'page_title': 'Restaurant Menu',
    }
    return render(request, 'hotels/menu_list.html', context)




from django.shortcuts import render, redirect,get_object_or_404
from django.core.files import File
from io import BytesIO
import qrcode
from .models import Table


@login_required
def menu_view(request, table_id):
    # Get the table object
    table = get_object_or_404(Table, id=table_id)
    
    # Get all food items from this table's hotel
    food_items = FoodItem.objects.filter(hotel=table.hotel)

    return render(request, "hotels/menu.html", {
        "table": table,
        "food_items": food_items
    })

@login_required
def create_table(request):
    if request.method == "POST":
        table_number = request.POST.get("table_number")
        seats = request.POST.get("seats")

        hotel = Hotel.objects.first()

        # Create table entry
        table = Table.objects.create(
            table_number=table_number,
            seats=seats,
            hotel=hotel,
        )

        # Generate QR code for this table's menu URL
        qr_url = f"http://127.0.0.1:8000/menu/{table.id}/"  # Change to your domain in production
        qr_img = qrcode.make(qr_url)
        buffer = BytesIO()
        qr_img.save(buffer, format='PNG')
        file_name = f'table-{table.id}-qr.png'
        table.qr_code.save(file_name, File(buffer), save=True)

        return redirect("table_list")

    return render(request, "hotels/create_table.html")



@login_required
def table_list(request):
    hotel = request.user.hotel  # Make sure User model has a hotel FK
    tables = Table.objects.filter(hotel=hotel).select_related('hotel')
    return render(request, "hotels/table_list.html", {"tables": tables})
    




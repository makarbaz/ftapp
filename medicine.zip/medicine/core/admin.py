from django.contrib import admin
from .models import Medicine

@admin.register(Medicine)
class MedicineAdmin(admin.ModelAdmin):
    list_display = ("product_name", "company_name", "mfg_date", "exp_date", "qr_generated_at")

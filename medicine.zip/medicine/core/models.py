from django.db import models
import qrcode
from io import BytesIO
from django.core.files import File
import json
from datetime import datetime

class Medicine(models.Model):
    company_name = models.CharField(max_length=255)
    product_name = models.CharField(max_length=255)
    mfg_date = models.DateField(verbose_name="Manufacturing Date")
    exp_date = models.DateField(verbose_name="Expiry Date")
    license_no = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    qr_code = models.ImageField(upload_to="qr_codes", blank=True)
    qr_generated_at = models.DateTimeField(auto_now_add=True)  # Stores QR generation date

    def save(self, *args, **kwargs):
        return f"{self.product_name} ({self.company_name})"
    
    def save(self, *args, **kwargs):
        super().save(*args, **kwargs) 

  
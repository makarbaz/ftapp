from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path("", views.home, name="home"),  # Home page
    path("login-page/", views.login_page, name="login_page"),
    path("logout/", views.logout_view, name="logout"),
    path("create/", views.medicine_create, name="medicine_create"),
    path('list/', views.medicine_list, name='medicine_list'),
    path('Dashboard/', views.Dashboard, name="dashboard"),
    path("medicine/<int:pk>/", views.medicine_detail, name="medicine_detail"),

    #path("verify/<int:pk>/", views.medicine_detail, name="medicine_detail"),
]
# Serve media files (QR codes) in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


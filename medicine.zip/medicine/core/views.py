from django.shortcuts import render, get_object_or_404,redirect
from .models import Medicine
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from datetime import date, timedelta

import qrcode
import io
from django.shortcuts import render, redirect
from django.core.files.base import ContentFile
from django.utils import timezone
def home(request):
   
    return render(request, "home.html")

def Dashboard(request):
    medicines = Medicine.objects.all()
    today = date.today()
    soon_threshold = today + timedelta(days=30)  # define "expiring soon" as within next 30 days

    total_medicines = Medicine.objects.count()
    expired_count = Medicine.objects.filter(exp_date__lt=today).count()
    expiring_soon_count = Medicine.objects.filter(exp_date__gte=today, exp_date__lte=soon_threshold).count()

    context = {
        'total_medicines': total_medicines,
        'expired_count': expired_count,
        'expiring_soon_count': expiring_soon_count,
        'medicines':medicines,
    }

    return render(request, "dashboard.html", context)


def login_page(request):

    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request,username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect("dashboard")
        else:
            messages("Invalid username or password")

   
    return render(request, "login.html")

# Logout view
def logout_view(request):
    logout(request)
    messages.success(request, "Logged out successfully.")
    return redirect("home")





def medicine_create(request):
    if request.method == "POST":
        company_name = request.POST.get('company_name')
        product_name = request.POST.get('product_name')
        mfg_date = request.POST.get('mfg_date')
        exp_date = request.POST.get('exp_date')
        license_no = request.POST.get('license_no')
        description = request.POST.get('description')

        # Create and save medicine without QR
        medicine = Medicine(
            company_name=company_name,
            product_name=product_name,
            mfg_date=mfg_date,
            exp_date=exp_date,
            license_no=license_no,
            description=description
        )
        medicine.save()

        # Prepare QR code data
        qr_data = {
            "id": medicine.id,
            "company_name": company_name,
            "product_name": product_name,
            "mfg_date": mfg_date,
            "exp_date": exp_date,
            "license_no": license_no,
            "description": description
        }

        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=1,
            border=4
        )
        qr.add_data(qr_data)
        qr.make(fit=True)

        matrix_size = qr.modules_count
        target_px = 76  # approx 2cm @ 96dpi
        box_size = max(1, target_px // (matrix_size + 2 * qr.border))

        # Regenerate QR with computed box size
        qr = qrcode.QRCode(
            version=qr.version,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=box_size,
            border=4
        )
        qr.add_data(qr_data)
        qr.make(fit=True)


        
        qr_img = qr.make_image(fill_color="black", back_color="white")

        buffer = io.BytesIO()
        qr_img.save(buffer, format="PNG", dpi=(96, 96))
        qr_file = ContentFile(buffer.getvalue())




        # Generate QR code
        # qr_img = qrcode.make(str(qr_data))
        # buffer = io.BytesIO()
        # qr_img.save(buffer, format="PNG")
        # qr_file = ContentFile(buffer.getvalue())

        # Save QR code file
        medicine.qr_code.save(f"medicine_{medicine.id}_qr.png", qr_file)
        medicine.save()

        return redirect('medicine_detail', pk=medicine.pk)

    return render(request, "create_medicine.html")


     
from datetime import timedelta

def medicine_list(request):
    medicines = Medicine.objects.all().order_by('-id')

    return render(request, 'medicine_list.html', {'medicines': medicines})




@login_required
def medicine_detail(request, pk):
    medicine = get_object_or_404(Medicine, id=pk)
    return render(request, "medicine_detail.html", {"medicine": medicine})
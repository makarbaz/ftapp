from django.db import models

# Create your models here.

#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
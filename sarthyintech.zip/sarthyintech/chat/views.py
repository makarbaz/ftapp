# chat/views.py

import openai
import json
import os
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from openai import OpenAI  # new client-style usage in v1+
from dotenv import load_dotenv
load_dotenv()

# Securely load OpenAI API key (use .env in production)
#openai.api_key = os.getenv("OPENAI_API_KEY", "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")


def index(request):
    return render(request, 'chat/index.html') 

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY", "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"))

@csrf_exempt
def chatbot(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            user_input = data.get('message')

            if not user_input:
                return JsonResponse({'response': 'Please enter a message.'}, status=400)

            # Updated method for ChatCompletion in v1+
            chat_response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a helpful AI tutor for class 1 to 10 students."},
                    {"role": "user", "content": user_input}
                ],
                temperature=0.5,
                max_tokens=150
            )

            reply = chat_response.choices[0].message.content.strip()
            return JsonResponse({"response": reply})

        except Exception as e:
            return JsonResponse({"response": f"Error: {str(e)}"}, status=500)

    return JsonResponse({'response': 'Only POST allowed'}, status=405)

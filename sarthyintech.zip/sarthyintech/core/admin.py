from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.utils.html import format_html

from .models import (
    School, CustomUser, ClassRoom, Subject,
    StudentProfile, TeacherProfile, LeaveRequest,

    Attendance, Result, Notice ,SchoolEvent, TimeTable, SchoolPayment,FeeRecord ,FeeStructure, Discount,
)

class CustomUserAdmin(UserAdmin):
    model = CustomUser
    list_display = ('username', 'email', 'first_name', 'last_name', 'role', 'school', 'is_staff', 'profile_image_tag')
    list_filter = ('role', 'school', 'is_active', 'is_staff')
    search_fields = ('username', 'email', 'first_name', 'last_name')
    ordering = ('username',)

    fieldsets = UserAdmin.fieldsets + (
        ('Additional Info', {
            'fields': ('role', 'school', 'profile_image')
        }),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ('Additional Info', {
            'fields': ('role', 'school', 'profile_image')
        }),
    )

    def profile_image_tag(self, obj):
        if obj.profile_image:
            return format_html('<img src="{}" style="height:40px; border-radius:50%;" />', obj.profile_image.url)
        return "No Image"
    profile_image_tag.short_description = 'Profile Image'

@admin.register(School)
class SchoolAdmin(admin.ModelAdmin):
    list_display = ('school_id', 'name', 'email', 'school_phone')
    search_fields = ('name', 'school_id', 'email', 'school_phone')
    list_filter = ('name',)
    readonly_fields = ('school_id',)

# @admin.register(StudentProfile)
# class StudentProfileAdmin(admin.ModelAdmin):
#     list_display = ['student_name', 'roll_number', 'classroom', 'date_of_birth', 'joining_date', 'leaving_date']
#     list_filter = ['classroom', 'joining_date', 'leaving_date']
#     search_fields = ['student_name', 'roll_number', 'father_name', 'mother_name']
#     readonly_fields = ['studemt_photo']
#     ordering = ['classroom', 'roll_number']



# For StudentProfile
@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = (
        'student_name',
        'roll_number',
        'classroom',
        'monthly_fee',
        'total_fee',
        'event_fee',
        
        'total_fee_paid_display',
        'total_fee_pending_display'
    )
    search_fields = ('student_name', 'roll_number', 'user__email')
    list_filter = ('classroom',)
    readonly_fields = ('total_fee_paid_display', 'total_fee_pending_display')

    def total_fee_paid_display(self, obj):
        return obj.total_fee_paid
    total_fee_paid_display.short_description = 'Total Fee Paid'

    def total_fee_pending_display(self, obj):
        return obj.total_fee_pending
    total_fee_pending_display.short_description = 'Total Fee Pending'

# For FeeRecord
@admin.register(FeeRecord)
class FeeRecordAdmin(admin.ModelAdmin):
    list_display = (
        'student',
        'slip_number',
        'amount',
        'month',
        'year',
        'payment_mode',
        'utr_number',
        'date'
    )
    search_fields = ('slip_number', 'student__student_name', 'utr_number')
    list_filter = ('payment_mode', 'month', 'year')










@admin.register(TeacherProfile)
class TeacherProfileAdmin(admin.ModelAdmin):
    list_display = ('get_name', 'get_email', 'phone_number', 'designation', 'get_subject', 'get_school')

    def get_name(self, obj):
        return obj.user.get_full_name()
    get_name.short_description = 'Full Name'

    def get_email(self, obj):
        return obj.user.email
    get_email.short_description = 'Email'

    def get_subject(self, obj):
        return obj.subject.name if obj.subject else '-'
    get_subject.short_description = 'Subject'

    def get_school(self, obj):
        return obj.user.school.name if obj.user.school else '-'
    get_school.short_description = 'School'

@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ['student', 'date', 'is_present']
    list_filter = ['date', 'is_present']

@admin.register(Result)
class ResultAdmin(admin.ModelAdmin):
    list_display = ['student', 'subject', 'marks']
    list_filter = ['subject', 'student__classroom']

@admin.register(Notice)
class NoticeAdmin(admin.ModelAdmin):
    list_display = ['title', 'classroom', 'created_at']
    list_filter = ['classroom', 'created_at']



@admin.register(TimeTable)
class TimeTableAdmin(admin.ModelAdmin):
    list_display = ('classroom', 'day_of_week', 'start_time', 'end_time', 'subject', 'teacher')
    list_filter = ('classroom', 'day_of_week', 'teacher')
    search_fields = ('classroom__name', 'subject__name', 'teacher__username')


@admin.register(SchoolEvent)
class SchoolEventAdmin(admin.ModelAdmin):
    list_display = ('title', 'event_date', 'location')
    search_fields = ('title', 'description', 'location')
    list_filter = ('event_date',)






@admin.register(SchoolPayment)
class SchoolPaymentAdmin(admin.ModelAdmin):
    list_display = (
        'school', 
        'month', 
        'amount_display', 
        'status', 
        'payment_id', 
        'order_id', 
        'utr_number', 
        'created_at'
    )
    list_filter = ('status', 'month', 'school')
    search_fields = ('school__name', 'payment_id', 'order_id', 'utr_number')
    ordering = ('-created_at',)

    def amount_display(self, obj):
        return f"₹{obj.amount / 100:.2f}"
    amount_display.short_description = 'Amount (₹)'


@admin.register(LeaveRequest)
class LeaveRequestAdmin(admin.ModelAdmin):
    list_display = ('teacher', 'start_date', 'end_date', 'is_approved', 'submitted_at')
    list_filter = ('is_approved', 'start_date')
    search_fields = ('teacher__first_name', 'teacher__last_name')


# Register remaining models without decorators
admin.site.register(CustomUser, CustomUserAdmin)
admin.site.register(ClassRoom)
admin.site.register(Subject)
admin.site.register(FeeStructure)
admin.site.register(Discount)
# admin.site.register(SchoolPayment)

# core/api_urls.py

from rest_framework.routers import DefaultRouter
from .views import *

router = DefaultRouter()
router.register('schools', SchoolViewSet)
router.register('students', StudentViewSet)
router.register('teachers', TeacherViewSet)
router.register('attendance', AttendanceViewSet)
router.register('results', ResultViewSet)

urlpatterns = router.urls

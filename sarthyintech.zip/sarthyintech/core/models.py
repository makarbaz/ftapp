# core/models.py

from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
import uuid
from django.core.validators import RegexValidator, EmailValidator
from django.conf import settings
import razorpay
from django.utils import timezone
from django.core.validators import MinValueValidator
from datetime import date
from django.contrib.auth import get_user_model
##############################################################################

class School(models.Model):
    school_id = models.CharField(max_length=10, unique=True, editable=False, blank=True)
    name = models.CharField(max_length=255)
    school_phone = models.CharField(max_length=12)
    email = models.EmailField(unique=True, validators=[EmailValidator(message="Enter a valid email address.")]) 
    school_phone = models.CharField(
        max_length=12,
        validators=[
            RegexValidator(
                regex=r'^[0-9]{10,12}$',
                message="Phone number must be 10 to 12 digits."
            )
        ]
    )
    install_charge = models.PositiveIntegerField(default=0, validators=[MinValueValidator(0)])
    address = models.TextField()
    logo = models.ImageField(upload_to='school_logos/', blank=True, null=True)

    def __str__(self):
        return f"{self.name} ({self.school_id})"

    def save(self, *args, **kwargs):
        if not self.school_id:
            # Generate a unique 6-digit alphanumeric ID (customizable)
            self.school_id = self.generate_unique_school_id()
        super().save(*args, **kwargs)
    
    def generate_unique_school_id(self):
        last_school = School.objects.order_by('-id').first()
        if last_school and last_school.school_id:
            last_number = int(last_school.school_id.replace('SCH', ''))
        else:
            last_number = 0
        new_number = last_number + 1
        return f"SCH{new_number:05d}"

    # def generate_unique_school_id(self):
    #     import random
    #     import string
    #     while True:
    #         school_id = 'SCH' + ''.join(random.choices(string.digits, k=6))
    #         if not School.objects.filter(school_id=school_id).exists():
    #             return school_id

######################################################################


class CustomUser(AbstractUser):
    ROLE_CHOICES = (
        ('admin', 'Admin'),
        ('principal', 'Principal'),
        ('teacher', 'Teacher'),
        ('student', 'Student'),
        ('staff', 'Staff'),
    )
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    school = models.ForeignKey(School, on_delete=models.CASCADE, null=True, blank=True)
    profile_image = models.ImageField(upload_to='profile_images/', blank=True, null=True)

    def __str__(self):
        return f"{self.username} ({self.role})"
##################################################################

class ClassRoom(models.Model):
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    name = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.name} - {self.school.name}"
#################################################################

class Subject(models.Model):
    classroom = models.ForeignKey(ClassRoom, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.name} ({self.classroom.name})"

################################################################

    
     # Only for UPI
######################################################
import random
import string

CustomUser = get_user_model()

class StudentProfile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    student_name = models.CharField(max_length=20)
    mother_name= models.CharField(max_length=20)
    father_name = models.CharField(max_length=20)
    roll_number = models.CharField(max_length=10, unique=True)
    date_of_birth = models.DateField(null=True, blank=True)
    joining_date = models.DateField(default=timezone.now)       # 📅 Joining
    leaving_date = models.DateField(null=True, blank=True) 
    classroom = models.ForeignKey(ClassRoom, on_delete=models.SET_NULL, null=True)
    studemt_photo = models.ImageField(upload_to='student_photos/', blank=True, null=True)
    
    student_id = models.CharField(max_length=20, unique=True, blank=True, null=True)

    phone_number = models.CharField(
        max_length=15,
        validators=[RegexValidator(r'^\+?\d{10,15}$')],
        help_text="Enter a valid phone number (e.g. +919876543210)"
    )

    monthly_fee = models.IntegerField(default=0)  # ₹ per month
    total_fee = models.IntegerField(default=0)    # Total academic/yearly fee
    event_fee = models.IntegerField(default=0)    # Additional fees for events, tours, etc.


    def __str__(self):
        return self.user.get_full_name()
    
    def generate_unique_student_id(self):
        prefix = "STU"
        while True:
            random_digits = ''.join(random.choices(string.digits, k=6))
            student_id = f"{prefix}{random_digits}"
            if not StudentProfile.objects.filter(student_id=student_id).exists():
                return student_id


    @property
    def grand_total_fee(self):
        return self.monthly_fee + self.event_fee
    # Full expected amount (tuition + event)
     

    @property
    def total_fee_paid(self):
        return sum(record.amount for record in self.fee_records.all())

    @property
    def total_fee_pending(self):
        return max(0, self.grand_total_fee - self.total_fee_paid)
    
    @property
    def is_current_month_pending(self):
        current_month = date.today().month
        current_year = date.today().year
        return not self.fee_records.filter(month=current_month, year=current_year).exists()


##########################################################

class FeeRecord(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='fee_records')
    slip_number = models.CharField(max_length=20, unique=True, blank=True)
    amount = models.IntegerField(default=0)
    date = models.DateField(default=timezone.now)
    description = models.TextField(blank=True, null=True)
    payment_mode = models.CharField(max_length=20)
    utr_number = models.CharField(max_length=30, blank=True, null=True)

    month = models.IntegerField(
        choices=[(i, timezone.datetime(2000, i, 1).strftime('%B')) for i in range(1, 13)],
        default=timezone.now().month
    )
    year = models.IntegerField(default=timezone.now().year)

    def __str__(self):
        return f"{self.student} - {self.amount} - {self.month}/{self.year}"


    

######################################################
    # def generate_unique_student_id(self):
    #     school_name = self.user.school.name if self.user and self.user.school else "GEN"
    #     prefix = school_name[:3].upper()
    #     last_student = StudentProfile.objects.filter(student_id__startswith=prefix).order_by('-id').first()
        
    #     if last_student and last_student.student_id:
    #         try:
    #             last_number = int(last_student.student_id[-6:])
    #         except:
    #             last_number = 0
    #     else:
    #         last_number = 0

    #     new_number = last_number + 1
    #     return f"{prefix}{new_number:06d}"

    # def __str__(self):
    #     return self.user.get_full_name()


###########################   TeacherProfile      ############################################

class TeacherProfile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    teacher_name = models.CharField(max_length=20)
    subject = models.ForeignKey(Subject, on_delete=models.SET_NULL, null=True)
    phone_number = models.CharField(
        max_length=12,
        validators=[
            RegexValidator(
                regex=r'^[0-9]{10,12}$',
                message="Phone number must be 10 to 12 digits."
            )
        ],
        null=True,
        blank=True
    )
    designation = models.CharField(max_length=100, blank=True, null=True)
    classes = models.ManyToManyField(ClassRoom, blank=True)

    def __str__(self):
        return f"{self.user.get_full_name()} - {self.designation if self.designation else 'No Designation'}"


######################################################################
class Attendance(models.Model):
    date = models.DateField()
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE)
    is_present = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.student} - {self.date}"

#########################################################
class Result(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    marks = models.FloatField()

    def __str__(self):
        return f"{self.student.user.username} - {self.subject.name} - {self.marks}"


class Notice(models.Model):
    classroom = models.ForeignKey(ClassRoom, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class SchoolEvent(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    event_date = models.DateField()
    event_time = models.CharField(max_length=100, blank=True, null=True)  # e.g., "10:00 AM - 12:00 PM"
    location = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return f"{self.title} on {self.event_date}"


#######################################################



class TimeTable(models.Model):
    classroom = models.ForeignKey(ClassRoom, on_delete=models.CASCADE)
    day_of_week = models.CharField(max_length=10, choices=[
        ('Monday', 'Monday'),
        ('Tuesday', 'Tuesday'),
        ('Wednesday', 'Wednesday'),
        ('Thursday', 'Thursday'),
        ('Friday', 'Friday'),
        ('Saturday', 'Saturday'),
    ])
    start_time = models.TimeField()
    end_time = models.TimeField()
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    teacher = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, limit_choices_to={'role': 'teacher'})

    def __str__(self):
        return f"{self.classroom.name} - {self.day_of_week} - {self.subject.name}"

class LeaveRequest(models.Model):
    teacher = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        limit_choices_to={'role': 'teacher'}
    )
    start_date = models.DateField()
    end_date = models.DateField()
    reason = models.TextField()
    is_approved = models.BooleanField(default=False)
    submitted_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.teacher.get_full_name()} | {self.start_date} to {self.end_date}"



########################## company payment formate #############################


# from django.db import models
# from django.utils import timezone
# from core.models import School


class FeeStructure(models.Model):
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    month = models.CharField(max_length=20)  # e.g., "July 2025"
    base_amount = models.IntegerField()  # In paise
    late_fee = models.IntegerField(default=0)  # Optional
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        unique_together = ('school', 'month')

    def __str__(self):
        return f"{self.school.name} | {self.month} | ₹{self.base_amount / 100}"




class Discount(models.Model):
    name = models.CharField(max_length=100)
    percentage = models.FloatField(help_text="Enter value like 10 for 10% discount")
    valid_from = models.DateField()
    valid_until = models.DateField()
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.name} ({self.percentage}%)"





class SchoolPayment(models.Model):
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    payment_id = models.CharField(max_length=100)       # Razorpay payment ID
    order_id = models.CharField(max_length=100)         # Razorpay order ID
    month = models.CharField(max_length=20)             # Example: "July 2025"
    amount = models.IntegerField()                      # In paise, Razorpay uses paise
    utr_number = models.CharField(max_length=100, blank=True, null=True)  # For bank transfers
    status = models.CharField(max_length=20, default='Success')  # or 'Pending', 'Failed'
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.school.name} | {self.month} | ₹{self.amount / 100}"

    class Meta:
        unique_together = ('school', 'month')  # Prevent duplicate payment for same month





# class staff(models.model):
#     first_name = models.CharField(max_length=20)
#     last_name = models.CharField(max_length=20)
#     phone_num = models.CharField(max_length=12)
#     department = models.CharField(max_length=20)
#     start_date = models.DateField()

#     address_c = models.CharField(max_length=100)
#     address_p = models.CharField(max_length=100)



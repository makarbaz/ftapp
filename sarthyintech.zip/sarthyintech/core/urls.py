# core/urls.py

from django.urls import path
from . import views
from chat import views as chat_views  # ✅ Also works, but less common in app-level files
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.home, name='home'),
    path('sarthy/', views.sarthy, name='sarthy'),
    path('login/', views.custom_login, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('change-password/', views.change_password, name='change_password'),
    # path('teacher/', views.teacher, name='teacher'),

    path('create-school/', views.create_school_view, name='create_school'),


#################### chat ######################

    # path('chatbot/', chat_views.chatbot, name='chatbot'),
    # path('chat/', chat_views.index, name='chat-ui'),





############################ admin ##################################

    path('create-timetable/', views.create_timetable_view, name='create_timetable'),
    path('view-timetable/', views.view_timetable_view, name='view_timetable'),
    path('install-charges/', views.schools_with_install_charge, name='install_charges'),

####################### teacher #####################

    path('teacher/', views.teacher, name='teacher'),
    path('add-student/', views.add_student, name='add_student'),
    path('add-classroom/', views.add_classroom, name='add_classroom'),
   # path('upload-classrooms/', views.upload_classrooms_excel, name='upload_classrooms_excel'),

   


######################## principal ########################
    path('principal/', views.principal, name='principal'),
    path('notice/add/', views.add_notice, name='add_notice'),
    path('notice/edit/<int:pk>/', views.edit_notice, name='edit_notice'),
    path('staff_management/', views.staff_management, name ='staff_management'),
    path('add-teacher/', views.add_teacher_view, name='add_teacher'),
    path('teachacher_list/', views.teacher_list_view, name='teacher-list'),

########################
    path('student-list/', views.student_list_view, name='student-list'),
    path('students/<int:student_id>/edit/', views.edit_student_view, name='edit-student'),
    path('students/<int:student_id>/pay/', views.pay_fee_view, name='pay-fee'),
    path('students/<int:student_id>/fees/',views.student_fee_records_view, name='student-fee-records'),



    
  #  path('students/', student_list_view, name='student_list'),



############################ student ##################################

    path('student/', views.student, name='student'),


    

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

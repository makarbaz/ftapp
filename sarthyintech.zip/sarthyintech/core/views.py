# core/views.py

from rest_framework import viewsets
from .models import School, StudentProfile, TeacherProfile, Attendance, Result,SchoolEvent, Notice, ClassRoom,Subject 
from .serializers import *

class SchoolViewSet(viewsets.ModelViewSet):
    queryset = School.objects.all()
    serializer_class = SchoolSerializer

class StudentViewSet(viewsets.ModelViewSet):
    queryset = StudentProfile.objects.all()
    serializer_class = StudentProfileSerializer

class TeacherViewSet(viewsets.ModelViewSet):
    queryset = TeacherProfile.objects.all()
    serializer_class = TeacherProfileSerializer

class AttendanceViewSet(viewsets.ModelViewSet):
    queryset = Attendance.objects.all()
    serializer_class = AttendanceSerializer

class ResultViewSet(viewsets.ModelViewSet):
    queryset = Result.objects.all()
    serializer_class = ResultSerializer
#########################################################################

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages  # adjust if model is in another app
from django.db import IntegrityError
import razorpay
from django.contrib.auth import logout
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.http import HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import get_object_or_404
from django.contrib.auth.hashers import make_password 
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.files.storage import FileSystemStorage
from django.utils.crypto import get_random_string
import random 
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.contrib.auth.views import PasswordChangeView
from django.urls import reverse_lazy
from django.contrib import messages
from datetime import date
from datetime import datetime



################################################################






def home(request):
    return render(request, 'home.html')


def logout_view(request):
    logout(request)
    return redirect('login')


###################### chanage password   ############################
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from django.shortcuts import render, redirect

@login_required
def change_password(request):
    if request.method == 'POST':
        old_password = request.POST.get('old_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')

        user = request.user

        if not user.check_password(old_password):
            messages.error(request, 'Old password is incorrect.')
        elif new_password != confirm_password:
            messages.error(request, 'New passwords do not match.')
        else:
            user.set_password(new_password)
            user.save()
            update_session_auth_hash(request, user)  # Important to keep the user logged in
            messages.success(request, 'Password changed successfully.')
            return redirect('/')  # Redirect to profile or another page

    return render(request, 'change_password.html')




############################################################



###############################################################







######################################## Student ###############
from .models import StudentProfile,ClassRoom, FeeRecord
from django.db.models import Q, Prefetch

@login_required
def student(request):
    events = SchoolEvent.objects.order_by('event_date')
    return render(request, 'students/home.html',{'events': events})


@login_required
def student_list_view(request):
    students = StudentProfile.objects.select_related('classroom') \
        .prefetch_related(
            Prefetch('fee_records', queryset=FeeRecord.objects.order_by('-date'))
        ).all()
    classes = ClassRoom.objects.all()

    q = request.GET.get('q')
    class_id = request.GET.get('class_id')

    if q:
        students = students.filter(
            Q(student_name__icontains=q) | Q(roll_number__icontains=q)
        )

    if class_id:
        students = students.filter(classroom_id=class_id)

    return render(request, 'principal/student-list.html', {
        'students': students,
        'classes': classes,
    })


@login_required
def edit_student_view(request, student_id):
    student = get_object_or_404(StudentProfile, id=student_id)
    classrooms = ClassRoom.objects.all()

    if request.method == 'POST':
        student.roll_number = request.POST.get('roll_number')
        student.student_name = request.POST.get('student_name')
        student.classroom_id = request.POST.get('classroom')
        student.phone_number = request.POST.get('phone_number')
        student.mother_name = request.POST.get('mother_name')
        student.father_name = request.POST.get('father_name')
        student.monthly_fee = request.POST.get('monthly_fee') or 0
        student.total_fee = request.POST.get('total_fee') or 0
        student.event_fee = request.POST.get('event_fee') or 0
        student.save()
        return redirect('student-list')

    return render(request, 'principal/edit_student.html', {
        'student': student,
        'classrooms': classrooms
    })




@login_required
def pay_fee_view(request, student_id):
    student = get_object_or_404(StudentProfile, id=student_id)
    today = date.today()

    if request.method == "POST":
        amount = int(request.POST.get("amount"))
        description = request.POST.get("description", "")
        payment_mode = request.POST.get("payment_mode", "")
        utr_number = request.POST.get("utr_number", "")
        slip_number = "SLIP" + str(random.randint(10000, 99999))

        FeeRecord.objects.create(
            student=student,
            slip_number=slip_number,
            amount=amount,
            description=description,
            payment_mode=payment_mode,
            utr_number=utr_number,
            month=today.month,
            year=today.year,
        )

        messages.success(request, f"₹{amount} paid successfully!")
        return redirect("student-fee-records", student_id=student.id)

    return render(request, "principal/pay_fee_student.html", {
        "student": student,
        "current_month": today.strftime('%B'),
        "current_year": today.year,
    })


# @login_required
# def pay_fee_view(request, student_id):
#     student = get_object_or_404(StudentProfile, id=student_id)

#     if request.method == "POST":
#         amount = int(request.POST.get("amount"))
#         description = request.POST.get("description", "")
#         payment_mode = request.POST.get("payment_mode", "")
#         utr_number = request.POST.get("utr_number", "")

#         # Generate a unique slip number
#         slip_number = "SLIP" + get_random_string(8).upper()

#         # Save fee record
#         FeeRecord.objects.create(
#             student=student,
#             slip_number=slip_number,
#             amount=amount,
#             description=description,
#             payment_mode=payment_mode,
#             utr_number=utr_number,
#             month=timezone.now().month,
#             year=timezone.now().year,
#         )

#         messages.success(request, f"₹{amount} paid successfully!")
#         return redirect("student-fee-records", student_id=student.id)

#     return render(request, "principal/pay_fee_student.html", {"student": student})



@login_required
def student_fee_records_view(request, student_id):
    student = get_object_or_404(StudentProfile, id=student_id)
    records = student.fee_records.order_by('-date')
    return render(request, 'principal/fee_records.html', {
        'student': student,
        'records': records
    })



############################### teacher ###################






from django.contrib.auth.decorators import login_required
from django.utils import timezone
from .models import TimeTable, SchoolEvent
import datetime

@login_required
def teacher(request):
    # Get current day (e.g., 'Monday')
    today = timezone.now().strftime('%A')

    # Filter TimeTable for today and the current teacher
    todays_classes = TimeTable.objects.filter(teacher=request.user, day_of_week=today)

    # Optional: greeting based on time
    now = timezone.now()
    if now.hour < 12:
        greeting = "Good Morning"
    elif now.hour < 18:
        greeting = "Good Afternoon"
    else:
        greeting = "Good Evening"

    # Events and context
    events = SchoolEvent.objects.order_by('event_date')
    todays_classes = TimeTable.objects.filter(teacher=request.user, day_of_week=today).order_by('start_time')


    return render(request, 'teachers/home.html', {
        'events': events,
        'user': request.user,
        'greeting': greeting,
        'todays_classes': todays_classes,
        'class_count': todays_classes.count(),
        'todays_classes': todays_classes,
        
    })





CustomUser = get_user_model()

 
def generate_unique_username(school_name):
    prefix = school_name[:3].upper()

    last_user = CustomUser.objects.filter(username__startswith=prefix).order_by('-id').first()

    if last_user and last_user.username[len(prefix):].isdigit():
        last_number = int(last_user.username[len(prefix):])
    else:
        last_number = 0

    new_number = last_number + 1
    return f"{prefix}{new_number:04d}"





@login_required
def add_student(request):
    if not request.user.is_superuser and request.user.role not in ['teacher', 'principal']:
        messages.error(request, "You don't have permission to add students.")
        return redirect('home')

    if request.method == 'POST':
        student_name = request.POST['student_name']
        mother_name = request.POST['mother_name']
        father_name = request.POST['father_name']
        date_of_birth = request.POST['date_of_birth']
        classroom_id = request.POST['classroom']

        try:
            classroom = ClassRoom.objects.get(id=classroom_id)
        except ClassRoom.DoesNotExist:
            messages.error(request, "Invalid classroom selected.")
            return redirect('add_student')

        school = request.user.school  # assuming the user has a `school` attribute

        # ✅ Generate username and password
        username = generate_unique_username(school.name)
        password = username  # default password is username

        # ✅ Create user
        user = CustomUser.objects.create_user(
            username=username,
            password=password,
            first_name=student_name,
            role='student',
            school=school
        )

        # ✅ Create student profile
        student_profile = StudentProfile.objects.create(
            user=user,
            student_name=student_name,
            mother_name=mother_name,
            father_name=father_name,
            date_of_birth=date_of_birth,
            classroom=classroom,
            roll_number=get_random_string(6).upper()
        )

        # ✅ Assign unique student ID
        student_profile.student_id = student_profile.generate_unique_student_id()
        student_profile.save()

        # ✅ Show message with credentials
        messages.success(request, f"Student added successfully! Username: {username}, Password: {password}")
        return redirect('add_student')

    classrooms = ClassRoom.objects.all()
    return render(request, 'teachers/add_student.html', {'classrooms': classrooms})


# @login_required
# def add_student(request):

#     if not request.user.is_superuser and request.user.role not in ['teacher', 'principal']:
#         messages.error(request, "You don't have permission to add classrooms.")
#         return redirect('home')

#     if request.method == 'POST':
#         student_name = request.POST['student_name']
#         mother_name = request.POST['mother_name']
#         father_name = request.POST['father_name']
#         date_of_birth = request.POST['date_of_birth']
#         classroom_id = request.POST['classroom']

#         classroom = ClassRoom.objects.get(id=classroom_id)
#         school = request.user.school  # assuming logged-in user is admin/principal with `school`

#         # ✅ Generate username and password
#         username = generate_unique_username(school.name)
#         password = username

#         # ✅ Create user
#         user = CustomUser.objects.create_user(
#             username=username,
#             password=password,
#             first_name=student_name,
#             role='student',
#             school=school
#         )

#         # ✅ Create student profile
#         student_profile = StudentProfile.objects.create(
#             user=user,
#             student_name=student_name,
#             mother_name=mother_name,
#             father_name=father_name,
#             date_of_birth=date_of_birth,
#             classroom=classroom,
#             roll_number=get_random_string(6).upper()
#         )

#         student_profile.student_id = student_profile.generate_unique_student_id()
#         student_profile.save()

#         # ✅ Show message
#         messages.success(request, f"Student added! Username: {username}, Password: {password}")
#         return redirect('add_student')

#     classrooms = ClassRoom.objects.all()
#     return render(request, 'teachers/add_student.html', {'classrooms': classrooms})






@login_required
def add_classroom(request):
    # Permission check: only allow admin or principal users
    if not request.user.is_superuser and request.user.role not in ['staff', 'teacher', 'principal']:
        messages.error(request, "You don't have permission to add classrooms.")
        return redirect('home')  # redirect to a safe default

    if request.method == 'POST':
        class_name = request.POST.get('class_name', '').strip()
        school_id = request.POST.get('school_id')

        if not class_name or not school_id:
            messages.error(request, "Both class name and school must be provided.")
            return redirect('add_classroom')

        # Get school safely using get_object_or_404 to avoid crash
        school = get_object_or_404(School, id=school_id)

        # Optional: Check if the class already exists in that school
        if ClassRoom.objects.filter(name__iexact=class_name, school=school).exists():
            messages.warning(request, f"Class '{class_name}' already exists in {school.name}.")
        else:
            ClassRoom.objects.create(name=class_name, school=school)
            messages.success(request, f"Class '{class_name}' added to {school.name}.")

        return redirect('add_classroom')

    # GET request: Show form with all schools
    schools = School.objects.all()
    return render(request, 'teachers/add_classroom.html', {'schools': schools})



# @login_required
# def add_classroom(request):
#     if request.method == 'POST':
#         class_name = request.POST.get('class_name')
#         school_id = request.POST.get('school_id')

#         school = School.objects.get(id=school_id)
#         ClassRoom.objects.create(name=class_name, school=school)

#         messages.success(request, f"Class '{class_name}' added to {school.name}")
#         return redirect('add_classroom')

#     schools = School.objects.all()
#     return render(request, 'add_classroom.html', {'schools': schools})




############################# pricipal #######################################



# def student_list_view(request):
#     students = StudentProfile.objects.select_related('user', 'classroom').all()
#     return render(request, 'principal/student_list.html', {'students': students})



@login_required
def principal(request):

     # Get current month and year
    now = timezone.now()
    current_month = now.month
    current_year = now.year
    today = date.today()

    notices = Notice.objects.order_by('created_at')
    students = StudentProfile.objects.select_related('user', 'classroom').all()
    teachers = TeacherProfile.objects.select_related('user', 'subject').all()

    total_students = students.count()
    total_teachers = teachers.count()

    

    new_students_this_month = StudentProfile.objects.filter(
        joining_date__month=current_month,
        joining_date__year=current_year
    ).count()


    
    # New same month last year
    new_students_last_year = StudentProfile.objects.filter(
        joining_date__month=current_month,
        joining_date__year=current_year - 1
    ).count()

    if new_students_last_year > 0:
        percent_change = round(
            ((new_students_this_month - new_students_last_year) / new_students_last_year) * 100, 2
        )
        percent_change_abs = abs(percent_change)
    else:
        percent_change = None
        percent_change_abs = None


    new_teachers_this_month = TeacherProfile.objects.filter(
        user__date_joined__month=current_month,
        user__date_joined__year=current_year
    ).count()


    new_teachers_this_month = TeacherProfile.objects.filter(
        user__date_joined__month=current_month,
        user__date_joined__year=current_year
    ).count()


    attendance_today = Attendance.objects.filter(date=today)
    present_today = attendance_today.filter(is_present=True).count()
    total_attendance_records = attendance_today.count()

    if total_attendance_records > 0:
        attendance_percent = round((present_today / total_attendance_records) * 100, 2)
    else:
        attendance_percent = 0.0
    
    # ✅ Add this line right after calculating attendance_percent
    attendance_below = round(100 - attendance_percent, 1)






    context = {
        'notices': notices,
        'total_students': total_students,
        'total_teachers': total_teachers,
        'students': students,
        'teachers': teachers,
        'new_students_this_month': new_students_this_month,
        'new_teachers_this_month': new_teachers_this_month,
        'percent_change': percent_change,
        'percent_change_abs': percent_change_abs,
        'attendance_percent': attendance_percent,
        'attendance_below': attendance_below,
    }
    return render(request, 'principal/home.html' , context)




@login_required
def teacher_list_view(request):
    user = request.user

    # Assuming `CustomUser` has a `school` ForeignKey or OneToOneField
    user_school = user.school  # adjust this based on your model

    teachers = TeacherProfile.objects.filter(user__school=user_school)

    return render(request, 'principal/list.html', {'teachers': teachers})





# from django.shortcuts import render, redirect, get_object_or_404
# from django.utils import timezone
from .models import FeeRecord, StudentProfile
import uuid
# from django.contrib.auth.decorators import login_required

def generate_slip_number():
    return f"SLIP{uuid.uuid4().hex[:8].upper()}"

@login_required
def create_fee_record(request):
    students = StudentProfile.objects.filter(user__school=request.user.school)

    if request.method == 'POST':
        student_id = request.POST.get('student')
        amount = request.POST.get('amount')
        payment_mode = request.POST.get('payment_mode')
        utr_number = request.POST.get('utr_number')
        description = request.POST.get('description')
        month = request.POST.get('month')
        year = request.POST.get('year')

        student = get_object_or_404(StudentProfile, id=student_id)
        slip_number = generate_slip_number()

        fee = FeeRecord.objects.create(
            student=student,
            slip_number=slip_number,
            amount=amount,
            payment_mode=payment_mode,
            utr_number=utr_number,
            description=description,
            month=month,
            year=year,
            date=timezone.now()
        )
        return redirect('fee-slip', slip_number=slip_number)

    return render(request, 'principal/create_fee_manual.html', {'students': students})



########################## ADD TEACHER #####################################


@login_required
def add_teacher_view(request):
    if request.user.role != 'principal':
        return redirect('dashboard')

    school = request.user.school
    subjects = Subject.objects.filter(classroom__school=school)
    classes = ClassRoom.objects.filter(school=school)

    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
     #   subject_id = request.POST.get('subject')
        role = request.POST.get('role') 
        designation = request.POST.get('designation')
        # selected_class_ids = request.POST.getlist('classes')  # ✅ list of class IDs

    #  subject = Subject.objects.get(id=subject_id)

        prefix = ''.join(name.upper().split())[:3]
        count = CustomUser.objects.filter(username__startswith=prefix).count() + 1
        username = f"{prefix}{count:03d}"
        password = str(random.randint(10000000, 99999999))

        user = CustomUser.objects.create_user(
            username=username,
            password=password,
            email=email,
            role=role,
            school=school,
            first_name=name
        )

        teacher_profile = TeacherProfile.objects.create(
            user=user,
            # subject=subject,
            phone_number=phone,
            designation=designation
        )

        # ✅ Assign multiple classes
        # teacher_profile.classes.set(selected_class_ids)

        context = {
            'username': username,
            'password': password,
            'email': email,
            'name': name,
            # 'subject': subject.name,
            'designation': designation,
            'school': school.name,
        }
        return render(request, 'principal/teacher_created.html', context)

    return render(request, 'principal/add_teacher.html', {'subjects': subjects, 'classes': classes})




#########################################

def staff_management(request):
    return render(request, 'principal/staff_management.html')

# CustomUser = get_user_model()



#############################################
def add_notice(request):
    classrooms = ClassRoom.objects.all()

    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        classroom_id = request.POST.get('classroom')

        if title and content and classroom_id:
            classroom = ClassRoom.objects.get(id=classroom_id)
            Notice.objects.create(
                title=title,
                content=content,
                classroom=classroom
            )
            return redirect('principal_notes')

    return render(request, 'principal/add_notice.html', {'classrooms': classrooms})

#################################################

def edit_notice(request, pk):
    notice = get_object_or_404(Notice, pk=pk)
    classrooms = ClassRoom.objects.all()

    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        classroom_id = request.POST.get('classroom')

        if title and content and classroom_id:
            classroom = ClassRoom.objects.get(id=classroom_id)
            notice.title = title
            notice.content = content
            notice.classroom = classroom
            notice.save()
            return redirect('principal_notes')

    return render(request, 'principal/edit_notice.html', {'notice': notice, 'classrooms': classrooms})








###########################################




####################


def custom_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
 
            # Check the user's role and redirect accordingly
            role = user.role  # assuming CustomUser has a 'role' field
            
            if role == 'student':
                return redirect('student')

            elif role == 'admin':
                return redirect('sarthy')

            elif role == 'teacher':
                return redirect('teacher')
            elif role == 'principal':
                return redirect('principal')
            else:
                messages.error(request, 'Invalid role assigned.')
                return redirect('login')
        else:
            messages.error(request, 'Invalid username or password')

    return render(request, 'login.html')


#################################################

@login_required
def create_timetable_view(request):
    if request.method == 'POST':
        classroom_id = request.POST.get('classroom')
        day = request.POST.get('day_of_week')
        subject_id = request.POST.get('subject')
        teacher_id = request.POST.get('teacher')
        start_time = request.POST.get('start_time')
        end_time = request.POST.get('end_time')

        TimeTable.objects.create(
            classroom_id=classroom_id,
            day_of_week=day,
            subject_id=subject_id,
            teacher_id=teacher_id,
            start_time=start_time,
            end_time=end_time
        )
        return redirect('view_timetable')  # Redirect to view after creation

    classrooms = ClassRoom.objects.all()
    subjects = Subject.objects.all()
    teachers = CustomUser.objects.filter(role='teacher')
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

    return render(request, 'teachers/create_timetable.html', {
        'classrooms': classrooms,
        'subjects': subjects,
        'teachers': teachers,
        'days':days,
    })

@login_required
def view_timetable_view(request):
    timetables = TimeTable.objects.all().order_by('classroom', 'day_of_week', 'start_time')
    return render(request, 'teachers/view_timetable.html', {
        'timetables': timetables
    })
 






 ########## Admin panal ##################

from .models import School, StudentProfile , SchoolPayment
from datetime import timedelta
from django.db.models import Sum
import calendar

 

User = get_user_model() 

def is_superuser(user):
    return user.is_superuser

@login_required
@user_passes_test(is_superuser)
def create_school_view(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        role = request.POST.get('role') 
        logo_file = request.FILES.get('logo')

        if School.objects.filter(email=email).exists():
            messages.error(request, "A school with this email already exists.")
            return render(request, 'sarthy/create_school.html')


        school = School(
            name=name,
            email=email,
            school_phone=phone,
            address=address,
            logo=logo_file
        )
        school.save()

        # Generate random password
        # password = get_random_string(length=8)
        password = str(random.randint(10000000, 99999999))


        # Create admin user for this school
        admin_user = User.objects.create_user(
            username=school.school_id,
            email=email,
            password=password,
            role=role,
            school=school,
            first_name=name + f" {role.capitalize()}"
        )

        context = {
            'school': school,
            'admin_user': admin_user,
            'generated_password': password
        }
        return render(request, 'sarthy/school_created.html', context)

    return render(request, 'sarthy/create_school.html')

#####################################################


@login_required
def sarthy(request):

    

    today = timezone.now()
    current_month_name = today.strftime('%B %Y')
    last_month = (today.replace(day=1) - timezone.timedelta(days=1))
    last_month_name = last_month.strftime('%B %Y')

    # Calculate revenue and counts
    current_month_payments = SchoolPayment.objects.filter(month=current_month_name, status='Success')
    last_month_payments = SchoolPayment.objects.filter(month=last_month_name, status='Success')

    current_month_revenue = sum(p.amount for p in current_month_payments) // 100  # to ₹
    last_month_revenue = sum(p.amount for p in last_month_payments) // 100

    percent_change = 0
    if last_month_revenue > 0:
        percent_change = round(((current_month_revenue - last_month_revenue) / last_month_revenue) * 100, 2)

    pending_payments = SchoolPayment.objects.filter(status='Pending')
    pending_amount = sum(p.amount for p in pending_payments) // 100

    completed_payment_count = SchoolPayment.objects.filter(status='Success').count()
    total_schools = School.objects.count()
    total_students = StudentProfile.objects.count()  # Assuming you have a Student model

    remaining_amount = total_students * 500 - current_month_revenue  # Example logic
    
    total_install_charges = School.objects.aggregate(total=Sum('install_charge'))['total'] or 0
    
    context = {
        'current_month_revenue': current_month_revenue,
        'percent_change': percent_change,
        'pending_amount': pending_amount,
        'completed_payment_count': completed_payment_count,
        'total_schools': total_schools,
        'total_students': total_students,
        'remaining_amount': remaining_amount,
        'total_install_charges': total_install_charges,
    }

    return render(request, 'sarthy/schoolpay.html', context)



############################

@login_required
def schools_with_install_charge(request):
    schools = School.objects.all()

    context ={
        'schools': schools

    }
    return render(request, 'sarthy/install_charge_list.html', context)





######################################



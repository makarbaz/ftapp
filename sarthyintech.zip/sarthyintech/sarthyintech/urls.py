# sarthyintech/urls.py or multiproject/urls.py

from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('core.urls')),  # 👈 include the core app URLs
    path('api/', include('core.api_urls')),
]
